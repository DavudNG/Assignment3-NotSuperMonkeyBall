using UnityEngine;

public class Level4Start : MonoBehaviour
{
    public InputHandler3D inputHandler;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        inputHandler.EnableAllInputs();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
